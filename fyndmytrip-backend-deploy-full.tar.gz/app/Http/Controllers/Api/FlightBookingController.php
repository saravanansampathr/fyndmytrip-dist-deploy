<?php

namespace App\Http\Controllers\Api;

use App\Domains\Booking\Models\Booking;
use App\Domains\Booking\Models\BookingAncillary;
use App\Domains\Booking\Services\BookingStatusService;
use App\Domains\Booking\Services\RouteClassificationService;
use App\Domains\Cashback\Services\CashbackService;
use App\Domains\Coupons\Exceptions\InvalidCouponException;
use App\Domains\Coupons\Services\CouponService;
use App\Domains\Payments\Models\PaymentTransaction;
use App\Domains\Payments\Services\PaymentGatewayService;
use App\Domains\Suppliers\DTOs\SearchRequest;
use App\Domains\Suppliers\Exceptions\SupplierException;
use App\Domains\Suppliers\Services\FlightSeatMapService;
use App\Domains\Suppliers\Services\MarkupService;
use App\Domains\Suppliers\Services\SupplierOrchestrator;
use App\Domains\Wallet\Exceptions\InsufficientBalanceException;
use App\Domains\Wallet\Models\Wallet;
use App\Domains\Wallet\Models\WalletLedgerEntry;
use App\Domains\Wallet\Services\WalletService;
use App\Http\Controllers\Controller;
use App\Http\Resources\BookingResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Demonstrates the full mock booking pipeline described in the Master Brief
 * (§6 Supplier integration, §7 Wallet) end to end: search -> hold -> pick
 * seats/meals/baggage/insurance -> apply a coupon -> confirm (pay), against
 * MockFlightSupplierAdapter until real TBO/TripJack/Akbar credentials are
 * configured. The same endpoints, unchanged in shape, will drive a real
 * supplier once one is registered in config/suppliers.php — only the
 * adapter class changes.
 */
class FlightBookingController extends Controller
{
    public function __construct(
        protected SupplierOrchestrator $orchestrator,
        protected MarkupService $markupService,
        protected WalletService $walletService,
        protected BookingStatusService $statusService,
        protected FlightSeatMapService $seatMapService,
        protected CouponService $couponService,
        protected RouteClassificationService $routeClassificationService,
        protected PaymentGatewayService $paymentGatewayService,
        protected CashbackService $cashbackService,
    ) {}

    public function search(Request $request)
    {
        $data = $request->validate([
            'origin' => ['required', 'string', 'size:3'],
            'destination' => ['required', 'string', 'size:3'],
            'departure_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:today'],
            'return_date' => ['nullable', 'date_format:Y-m-d', 'after:departure_date'],
            'passenger_count' => ['nullable', 'integer', 'min:1', 'max:9'],
        ]);

        $user = $request->user();
        $searchRequest = new SearchRequest(
            module: Booking::MODULE_FLIGHT,
            origin: strtoupper($data['origin']),
            destination: strtoupper($data['destination']),
            departureDate: $data['departure_date'],
            returnDate: $data['return_date'] ?? null,
            passengerCount: $data['passenger_count'] ?? 1,
        );

        $results = $this->orchestrator->search($user->tenant, $searchRequest);

        $role = $this->markupRoleFor($user);

        $results = array_map(function (array $item) use ($user, $role) {
            $pricing = $this->markupService->applyMarkup($user->tenant, Booking::MODULE_FLIGHT, $role, $item['net_amount']);

            return array_merge($item, $pricing);
        }, $results);

        return response()->json(['data' => $results]);
    }

    public function ancillaryCatalog()
    {
        return response()->json(['data' => config('ancillaries')]);
    }

    public function hold(Request $request)
    {
        $data = $request->validate([
            'supplier_code' => ['required', 'string'],
            'external_id' => ['required', 'string'],
            'travel_date' => ['required', 'date_format:Y-m-d'],
            'segments' => ['nullable', 'array'],
            'contact_email' => ['nullable', 'email', 'max:191'],
            'contact_phone' => ['nullable', 'string', 'max:30'],
            'passengers' => ['required', 'array', 'min:1', 'max:9'],
            'passengers.*.title' => ['nullable', 'string', 'in:Mr,Mrs,Ms,Miss,Master,Dr'],
            'passengers.*.name' => ['required', 'string', 'max:191'],
            'passengers.*.dob' => ['nullable', 'date'],
            'passengers.*.gender' => ['nullable', 'in:male,female,other,unspecified'],
            'passengers.*.document_type' => ['nullable', 'in:passport,aadhaar,pan,voter_id,driving_license,other'],
            'passengers.*.document_number' => ['nullable', 'string', 'max:60'],
        ]);

        $user = $request->user();
        $tenant = $user->tenant;

        try {
            $fareRule = $this->orchestrator->priceCheck($tenant, $data['supplier_code'], $data['external_id']);
        } catch (SupplierException $e) {
            return response()->json(['message' => $e->getMessage()], 502);
        }

        if (! $fareRule->isStillAvailable) {
            return response()->json(['message' => 'This fare is no longer available. Please search again.'], 409);
        }

        $role = $this->markupRoleFor($user);
        $pricing = $this->markupService->applyMarkup($tenant, Booking::MODULE_FLIGHT, $role, $fareRule->confirmedNetAmount);

        $booking = Booking::create([
            'tenant_id' => $tenant->id,
            'created_by_user_id' => $user->id,
            'module' => Booking::MODULE_FLIGHT,
            'supplier_code' => $data['supplier_code'],
            'gross_amount' => $pricing['gross_amount'],
            'supplier_net_amount' => $fareRule->confirmedNetAmount,
            'markup_amount' => $pricing['markup_amount'],
            'travel_date_start' => $data['travel_date'],
            'passenger_count' => count($data['passengers']),
            'contact_email' => $data['contact_email'] ?? $user->email,
            'contact_phone' => $data['contact_phone'] ?? $user->phone,
        ]);

        foreach ($data['passengers'] as $passenger) {
            $booking->passengers()->create($passenger);
        }

        foreach ($data['segments'] ?? [] as $segment) {
            $booking->segments()->create([
                'sequence' => $segment['sequence'] ?? 1,
                'origin' => $segment['origin'] ?? null,
                'destination' => $segment['destination'] ?? null,
                'departure_at' => $segment['departure_at'] ?? null,
                'arrival_at' => $segment['arrival_at'] ?? null,
                'carrier_or_provider' => $segment['carrier_or_provider'] ?? null,
                'fare_basis' => $segment['fare_basis'] ?? null,
                'raw_supplier_payload' => $segment,
            ]);
        }

        try {
            $hold = $this->orchestrator->hold($tenant, $data['supplier_code'], $data['external_id'], $data['passengers']);
        } catch (SupplierException $e) {
            $this->statusService->transition($booking, Booking::STATUS_FAILED, $user, $e->getMessage());

            return response()->json(['message' => $e->getMessage()], 502);
        }

        $booking->load('segments');
        $booking->update([
            'supplier_booking_ref' => $hold->supplierBookingRef,
            'is_international' => $this->routeClassificationService->isInternational($booking),
        ]);
        $this->statusService->transition($booking, Booking::STATUS_HELD, $user, 'Supplier hold confirmed.');

        return response()->json([
            'data' => new BookingResource($booking->fresh(['passengers', 'segments'])),
            'hold_expires_at' => $hold->holdExpiresAt->format(DATE_ATOM),
        ], 201);
    }

    /**
     * Seat layout for the (single-segment) flight this booking is on, with
     * availability worked out from the deterministic mock map plus real
     * flight_seat_locks reservations — see FlightSeatMapService.
     */
    public function seatMap(Request $request, Booking $booking)
    {
        $segment = $booking->segments()->orderBy('sequence')->first();

        if (! $segment || ! ($segment->raw_supplier_payload['flight_number'] ?? null)) {
            return response()->json(['message' => 'No flight is attached to this booking yet.'], 422);
        }

        $flightNumber = $segment->raw_supplier_payload['flight_number'];
        $aircraftType = $segment->raw_supplier_payload['aircraft_type'] ?? 'Airbus A320';
        $travelDate = $booking->travel_date_start->toDateString();

        $map = $this->seatMapService->generate($flightNumber, $travelDate, $aircraftType);

        $currentSelections = $booking->passengers()
            ->whereNotNull('seat_number')
            ->pluck('seat_number', 'id');

        return response()->json([
            'data' => $map,
            'current_selections' => $currentSelections,
            'extra_legroom_fee' => FlightSeatMapService::EXTRA_LEGROOM_FEE,
        ]);
    }

    /**
     * Seats + meals + baggage + insurance + misc. services, one entry per
     * passenger. Re-submittable while the booking is still 'held' — each
     * call replaces the booking's previous selections from scratch.
     */
    public function extras(Request $request, Booking $booking)
    {
        if ($booking->status !== Booking::STATUS_HELD) {
            return response()->json(['message' => "Extras can only be set while a booking is 'held'; it is currently '{$booking->status}'."], 409);
        }

        $data = $request->validate([
            'passengers' => ['required', 'array', 'min:1'],
            'passengers.*.passenger_id' => ['required', 'integer'],
            'passengers.*.seat_number' => ['nullable', 'string', 'max:5'],
            'passengers.*.meal_code' => ['nullable', 'string'],
            'passengers.*.baggage_code' => ['nullable', 'string'],
            'passengers.*.insurance_code' => ['nullable', 'string'],
            'passengers.*.other_codes' => ['nullable', 'array'],
            'passengers.*.other_codes.*' => ['string'],
        ]);

        $passengerIds = $booking->passengers()->pluck('id')->all();

        foreach ($data['passengers'] as $row) {
            if (! in_array($row['passenger_id'], $passengerIds, true)) {
                return response()->json(['message' => 'One or more passengers do not belong to this booking.'], 422);
            }
        }

        $segment = $booking->segments()->orderBy('sequence')->first();
        $flightNumber = $segment?->raw_supplier_payload['flight_number'] ?? null;
        $aircraftType = $segment?->raw_supplier_payload['aircraft_type'] ?? 'Airbus A320';
        $travelDate = $booking->travel_date_start->toDateString();

        $catalog = config('ancillaries');
        $catalogIndex = [];
        foreach (['meals', 'baggage', 'other', 'insurance'] as $group) {
            foreach ($catalog[$group] as $entry) {
                $catalogIndex[$entry['code']] = $entry;
            }
        }

        try {
            DB::transaction(function () use ($data, $booking, $flightNumber, $aircraftType, $travelDate, $catalogIndex) {
                // Wipe previous selections so this endpoint is safely
                // re-submittable (e.g. the customer goes back a step).
                $this->seatMapService->releaseForBooking($booking->id);
                $booking->ancillaries()->delete();
                $booking->passengers()->update(['seat_number' => null]);

                $extrasTotal = \Brick\Math\BigDecimal::of('0.00');

                foreach ($data['passengers'] as $row) {
                    $passenger = $booking->passengers()->findOrFail($row['passenger_id']);

                    if (! empty($row['seat_number']) && $flightNumber) {
                        $seatNumber = strtoupper($row['seat_number']);
                        $map = $this->seatMapService->generate($flightNumber, $travelDate, $aircraftType);
                        $seatInfo = collect($map['rows'])->flatMap(fn ($r) => $r['seats'])->firstWhere('seat_number', $seatNumber);

                        if (! $seatInfo || ! $seatInfo['available']) {
                            throw new \RuntimeException("Seat {$seatNumber} is not available.");
                        }

                        $this->seatMapService->reserve($flightNumber, $travelDate, $seatNumber, $booking->id, $passenger->id);
                        $passenger->update(['seat_number' => $seatNumber]);

                        if ((float) $seatInfo['fare'] > 0) {
                            $booking->ancillaries()->create([
                                'booking_passenger_id' => $passenger->id,
                                'category' => BookingAncillary::CATEGORY_OTHER,
                                'code' => 'extra_legroom_seat',
                                'label' => "Extra legroom seat {$seatNumber}",
                                'amount' => $seatInfo['fare'],
                            ]);
                            $extrasTotal = $extrasTotal->plus($seatInfo['fare']);
                        }
                    }

                    foreach (['meal_code' => BookingAncillary::CATEGORY_MEAL, 'baggage_code' => BookingAncillary::CATEGORY_BAGGAGE, 'insurance_code' => BookingAncillary::CATEGORY_INSURANCE] as $field => $category) {
                        $code = $row[$field] ?? null;

                        if (! $code || ! isset($catalogIndex[$code]) || (float) $catalogIndex[$code]['amount'] <= 0) {
                            continue;
                        }

                        $entry = $catalogIndex[$code];
                        $booking->ancillaries()->create([
                            'booking_passenger_id' => $passenger->id,
                            'category' => $category,
                            'code' => $code,
                            'label' => $entry['label'],
                            'amount' => $entry['amount'],
                        ]);
                        $extrasTotal = $extrasTotal->plus($entry['amount']);
                    }

                    foreach ($row['other_codes'] ?? [] as $code) {
                        if (! isset($catalogIndex[$code]) || (float) $catalogIndex[$code]['amount'] <= 0) {
                            continue;
                        }

                        $entry = $catalogIndex[$code];
                        $booking->ancillaries()->create([
                            'booking_passenger_id' => $passenger->id,
                            'category' => BookingAncillary::CATEGORY_OTHER,
                            'code' => $code,
                            'label' => $entry['label'],
                            'amount' => $entry['amount'],
                        ]);
                        $extrasTotal = $extrasTotal->plus($entry['amount']);
                    }
                }

                $booking->extras_amount = (string) $extrasTotal->toScale(2, \Brick\Math\RoundingMode::HALF_UP);
                $booking->total_amount = $booking->recalculateTotal();
                $booking->save();
            });
        } catch (\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 409);
        }

        return new BookingResource($booking->fresh(['passengers', 'segments', 'ancillaries']));
    }

    public function applyCoupon(Request $request, Booking $booking)
    {
        if ($booking->status !== Booking::STATUS_HELD) {
            return response()->json(['message' => "A coupon can only be applied while a booking is 'held'; it is currently '{$booking->status}'."], 409);
        }

        $data = $request->validate(['code' => ['required', 'string', 'max:30']]);
        $user = $request->user();

        $baseAmount = \Brick\Math\BigDecimal::of((string) $booking->gross_amount)
            ->plus((string) $booking->extras_amount);

        try {
            $coupon = $this->couponService->validate($data['code'], $user->tenant, $user, $booking->module, (string) $baseAmount);
        } catch (InvalidCouponException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        $discount = $this->couponService->calculateDiscount($coupon, (string) $baseAmount);

        $booking->coupon_code = $coupon->code;
        $booking->discount_amount = $discount;
        $booking->total_amount = $booking->recalculateTotal();
        $booking->save();

        return new BookingResource($booking->fresh(['passengers', 'segments', 'ancillaries']));
    }

    public function removeCoupon(Request $request, Booking $booking)
    {
        $booking->coupon_code = null;
        $booking->discount_amount = '0.00';
        $booking->total_amount = $booking->recalculateTotal();
        $booking->save();

        return new BookingResource($booking->fresh(['passengers', 'segments', 'ancillaries']));
    }

    /**
     * Domestic bookings pay instantly from the wallet, same as before.
     * International bookings must never be paid by a direct wallet debit
     * (they may still top up/recharge the wallet separately via
     * WalletController::topup — that's unrelated to how a *booking* is
     * paid) — this branch only opens a PaymentTransaction and hands the
     * frontend a "requires_payment" response; the booking stays 'held'
     * until payGateway() below reports the gateway succeeded.
     */
    public function confirm(Request $request, Booking $booking)
    {
        $user = $request->user();

        if ($booking->status !== Booking::STATUS_HELD) {
            return response()->json(['message' => "Booking must be 'held' to confirm; it is currently '{$booking->status}'."], 409);
        }

        $payable = $booking->recalculateTotal();

        if ($booking->is_international) {
            $transaction = $this->paymentGatewayService->initiate($booking, $payable);

            return response()->json([
                'requires_payment' => true,
                'data' => new BookingResource($booking->fresh(['passengers', 'segments', 'ancillaries'])),
                'payment' => [
                    'transaction_id' => $transaction->id,
                    'gateway' => $transaction->gateway,
                    'amount' => $transaction->amount,
                    'currency' => $transaction->currency,
                    // So the frontend's method picker can show which gateway
                    // each option (credit card, UPI, ...) will route to
                    // before the customer commits to one.
                    'available_methods' => $this->paymentGatewayService->availableMethods($booking->tenant),
                ],
            ]);
        }

        $wallet = Wallet::query()->firstOrCreate([
            'tenant_id' => $booking->tenant_id,
            'owner_type' => Wallet::OWNER_USER,
            'owner_id' => $user->id,
        ]);

        $couponCode = $booking->coupon_code;
        $discountAmount = (string) $booking->discount_amount;

        try {
            DB::transaction(function () use ($booking, $wallet, $payable, $couponCode, $discountAmount, $user) {
                if ($couponCode) {
                    $this->couponService->redeemWithAmount($couponCode, $booking->tenant, $user, $booking, $discountAmount);
                }

                $this->walletService->debit(
                    $wallet,
                    $payable,
                    WalletLedgerEntry::REF_BOOKING_PAYMENT,
                    $booking->id,
                    "Payment for booking {$booking->booking_reference}",
                    $user->id,
                );

                $booking->total_amount = $payable;
                $booking->save();
            });
        } catch (InsufficientBalanceException $e) {
            return response()->json(['message' => $e->getMessage()], 402);
        } catch (InvalidCouponException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        $this->statusService->transition($booking, Booking::STATUS_CONFIRMED, $user, 'Wallet payment captured.');

        return $this->finalizeTicketing($booking, $user);
    }

    /**
     * "The gateway succeeded" — the server-to-server webhook moment a real
     * Razorpay/PayU/etc. integration would drive; here it's called by the
     * frontend's mock payment step (see PaymentGatewayService's docblock).
     * Only valid for an international booking with a pending transaction.
     */
    public function payGateway(Request $request, Booking $booking)
    {
        $user = $request->user();

        if (! $booking->is_international) {
            return response()->json(['message' => 'This booking is not routed through the payment gateway.'], 422);
        }

        if ($booking->status !== Booking::STATUS_HELD) {
            return response()->json(['message' => "Booking must be 'held' to pay; it is currently '{$booking->status}'."], 409);
        }

        $transaction = PaymentTransaction::query()
            ->where('booking_id', $booking->id)
            ->where('status', PaymentTransaction::STATUS_INITIATED)
            ->latest()
            ->first();

        if (! $transaction) {
            return response()->json(['message' => 'No pending payment was found for this booking. Call confirm first.'], 409);
        }

        $data = $request->validate([
            'method' => ['required', 'string', 'in:'.implode(',', PaymentMethodRoute::METHODS)],
        ]);
        $method = $data['method'];

        $payable = $booking->recalculateTotal();
        $couponCode = $booking->coupon_code;
        $discountAmount = (string) $booking->discount_amount;

        try {
            DB::transaction(function () use ($booking, $transaction, $payable, $couponCode, $discountAmount, $user, $method) {
                if ($couponCode) {
                    $this->couponService->redeemWithAmount($couponCode, $booking->tenant, $user, $booking, $discountAmount);
                }

                $this->paymentGatewayService->settle($transaction, $booking->tenant, $method);

                $booking->total_amount = $payable;
                $booking->save();
            });
        } catch (InvalidCouponException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        $this->statusService->transition($booking, Booking::STATUS_CONFIRMED, $user, "Payment gateway ({$transaction->gateway}) captured.");

        return $this->finalizeTicketing($booking, $user);
    }

    /**
     * Shared tail for both payment paths once the booking is CONFIRMED:
     * ticket with the supplier, then credit any cashback the rule engine
     * awards — see CashbackService.
     */
    protected function finalizeTicketing(Booking $booking, User $user)
    {
        try {
            $confirmResult = $this->orchestrator->confirm($booking->tenant, $booking->supplier_code, $booking->supplier_booking_ref);
        } catch (SupplierException $e) {
            $this->statusService->transition($booking, Booking::STATUS_FAILED, $user, $e->getMessage());

            return response()->json(['message' => $e->getMessage()], 502);
        }

        $booking->update(['metadata' => array_merge($booking->metadata ?? [], ['ticket_numbers' => $confirmResult->ticketNumbers])]);
        $this->statusService->transition($booking, Booking::STATUS_TICKETED, $user, 'Supplier ticketing confirmed.');

        $this->cashbackService->applyCashback($booking, $user);

        return new BookingResource($booking->fresh(['passengers', 'segments', 'ancillaries']));
    }

    public function show(Request $request, Booking $booking)
    {
        return new BookingResource($booking->load(['passengers', 'segments', 'statusHistory', 'ancillaries']));
    }

    public function index(Request $request)
    {
        $bookings = Booking::query()
            ->where('module', Booking::MODULE_FLIGHT)
            ->orderByDesc('created_at')
            ->paginate($request->integer('per_page', 25));

        return BookingResource::collection($bookings);
    }

    protected function markupRoleFor(User $user): string
    {
        return match ($user->role) {
            User::ROLE_AGENT, User::ROLE_PARTNER_ADMIN => 'agent',
            User::ROLE_SUB_AGENT => 'sub_agent',
            default => 'b2c',
        };
    }
}
