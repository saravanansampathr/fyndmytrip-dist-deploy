<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin \App\Domains\Booking\Models\Booking
 */
class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'booking_reference' => $this->booking_reference,
            'module' => $this->module,
            'is_international' => (bool) $this->is_international,
            'supplier_code' => $this->supplier_code,
            'supplier_booking_ref' => $this->supplier_booking_ref,
            'status' => $this->status,
            'gross_amount' => (string) $this->gross_amount,
            'supplier_net_amount' => (string) $this->supplier_net_amount,
            'markup_amount' => (string) $this->markup_amount,
            'extras_amount' => (string) $this->extras_amount,
            'coupon_code' => $this->coupon_code,
            'discount_amount' => (string) $this->discount_amount,
            'total_amount' => (string) ($this->total_amount && (float) $this->total_amount > 0 ? $this->total_amount : $this->recalculateTotal()),
            'currency' => $this->currency,
            'travel_date_start' => $this->travel_date_start?->toDateString(),
            'travel_date_end' => $this->travel_date_end?->toDateString(),
            'passenger_count' => $this->passenger_count,
            'contact_email' => $this->contact_email,
            'contact_phone' => $this->contact_phone,
            'segments' => $this->whenLoaded('segments'),
            'passengers' => $this->whenLoaded('passengers'),
            'ancillaries' => $this->whenLoaded('ancillaries'),
            'status_history' => $this->whenLoaded('statusHistory'),
            'metadata' => $this->metadata,
            'created_at' => $this->created_at,
        ];
    }
}
