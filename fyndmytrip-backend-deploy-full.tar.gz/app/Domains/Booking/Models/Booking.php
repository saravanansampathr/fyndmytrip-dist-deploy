<?php

namespace App\Domains\Booking\Models;

use App\Domains\Tenancy\Concerns\BelongsToTenant;
use App\Domains\Tenancy\Models\Tenant;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * A single generic booking schema serves all eight Product Modules — see
 * Database Design Document §4 and the System Architecture Document's
 * Booking Orchestration Layer. Module-specific detail lives in the module
 * ENUM plus the metadata JSON column and booking_segments, not per-module
 * table forks.
 *
 * @property int $id
 * @property string $booking_reference
 * @property int $tenant_id
 * @property int|null $agent_tenant_id
 * @property int $created_by_user_id
 * @property string $module
 * @property string $supplier_code
 * @property string|null $supplier_booking_ref
 * @property string $status
 * @property string $gross_amount
 * @property string $supplier_net_amount
 * @property string $markup_amount
 * @property string $commission_amount
 */
class Booking extends Model
{
    use BelongsToTenant, HasFactory, SoftDeletes;

    public const MODULE_FLIGHT = 'flight';
    public const MODULE_HOTEL = 'hotel';
    public const MODULE_BUS = 'bus';
    public const MODULE_CAB = 'cab';
    public const MODULE_HOLIDAY = 'holiday';
    public const MODULE_INSURANCE = 'insurance';
    public const MODULE_VISA = 'visa';
    public const MODULE_CRUISE = 'cruise';

    public const STATUS_CART = 'cart';
    public const STATUS_HELD = 'held';
    public const STATUS_CONFIRMED = 'confirmed';
    public const STATUS_TICKETED = 'ticketed';
    public const STATUS_CANCELLED = 'cancelled';
    public const STATUS_FAILED = 'failed';
    public const STATUS_REFUNDED = 'refunded';

    protected $fillable = [
        'tenant_id',
        'agent_tenant_id',
        'created_by_user_id',
        'module',
        'is_international',
        'supplier_code',
        'supplier_booking_ref',
        'status',
        'gross_amount',
        'supplier_net_amount',
        'markup_amount',
        'commission_amount',
        'currency',
        'travel_date_start',
        'travel_date_end',
        'passenger_count',
        'contact_email',
        'contact_phone',
        'extras_amount',
        'coupon_code',
        'discount_amount',
        'total_amount',
        'metadata',
    ];

    protected $casts = [
        'is_international' => 'boolean',
        'gross_amount' => 'decimal:2',
        'supplier_net_amount' => 'decimal:2',
        'markup_amount' => 'decimal:2',
        'commission_amount' => 'decimal:2',
        'extras_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'travel_date_start' => 'date',
        'travel_date_end' => 'date',
        'metadata' => 'array',
    ];

    protected static function booted(): void
    {
        static::creating(function (self $booking) {
            if (empty($booking->booking_reference)) {
                $booking->booking_reference = (string) \Illuminate\Support\Str::uuid();
            }

            if (empty($booking->status)) {
                $booking->status = self::STATUS_CART;
            }

            if (empty($booking->currency)) {
                $booking->currency = 'INR';
            }

            if (empty($booking->markup_amount)) {
                $booking->markup_amount = '0.00';
            }

            if (empty($booking->commission_amount)) {
                $booking->commission_amount = '0.00';
            }

            if (empty($booking->passenger_count)) {
                $booking->passenger_count = 1;
            }

            if (empty($booking->extras_amount)) {
                $booking->extras_amount = '0.00';
            }

            if (empty($booking->discount_amount)) {
                $booking->discount_amount = '0.00';
            }

            if (empty($booking->total_amount)) {
                $booking->total_amount = $booking->gross_amount;
            }
        });
    }

    /**
     * What the customer actually owes right now: base fare + markup,
     * plus seats/meals/baggage/insurance, minus any applied coupon. This
     * is recalculated whenever extras or a coupon change (see
     * FlightBookingController::extras()/applyCoupon()) and is what
     * confirm() debits from the wallet.
     */
    public function recalculateTotal(): string
    {
        $total = \Brick\Math\BigDecimal::of((string) $this->gross_amount)
            ->plus((string) $this->extras_amount)
            ->minus((string) $this->discount_amount);

        return (string) $total->toScale(2, \Brick\Math\RoundingMode::HALF_UP);
    }

    public function ancillaries(): HasMany
    {
        return $this->hasMany(BookingAncillary::class);
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class, 'tenant_id');
    }

    public function agentTenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class, 'agent_tenant_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    public function passengers(): HasMany
    {
        return $this->hasMany(BookingPassenger::class);
    }

    public function segments(): HasMany
    {
        return $this->hasMany(BookingSegment::class)->orderBy('sequence');
    }

    public function statusHistory(): HasMany
    {
        return $this->hasMany(BookingStatusHistory::class)->orderBy('created_at');
    }

    public function isTerminal(): bool
    {
        return in_array($this->status, [self::STATUS_CANCELLED, self::STATUS_FAILED, self::STATUS_REFUNDED], true);
    }
}
