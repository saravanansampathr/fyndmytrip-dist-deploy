<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CashbackRuleController;
use App\Http\Controllers\Api\CouponController;
use App\Http\Controllers\Api\FlightBookingController;
use App\Http\Controllers\Api\PaymentMethodRouteController;
use App\Http\Controllers\Api\TenantController;
use App\Http\Controllers\Api\WalletController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Every route below runs behind the 'tenant' middleware (ResolveTenant),
| which binds the acting tenant into TenantContext before any controller
| or model global scope runs — see Database Design Document §3 and the
| System Architecture Document's tenant-context middleware.
|
*/

Route::middleware('tenant')->group(function () {
    Route::post('/auth/register', [AuthController::class, 'register'])->name('auth.register');
    Route::post('/auth/login', [AuthController::class, 'login'])->name('auth.login');

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/auth/logout', [AuthController::class, 'logout'])->name('auth.logout');
        Route::get('/auth/me', [AuthController::class, 'me'])->name('auth.me');

        Route::apiResource('tenants', TenantController::class)->only(['index', 'show', 'store']);

        Route::get('/wallet', [WalletController::class, 'me']);
        Route::get('/wallet/statement', [WalletController::class, 'statement']);
        Route::post('/wallet/topup', [WalletController::class, 'topup']);

        Route::post('/coupons/validate', [CouponController::class, 'validateCoupon']);

        Route::get('/flights/bookings', [FlightBookingController::class, 'index']);
        Route::post('/flights/search', [FlightBookingController::class, 'search']);
        Route::get('/flights/ancillary-catalog', [FlightBookingController::class, 'ancillaryCatalog']);
        Route::post('/flights/bookings', [FlightBookingController::class, 'hold']);
        Route::get('/flights/bookings/{booking}', [FlightBookingController::class, 'show']);
        Route::get('/flights/bookings/{booking}/seatmap', [FlightBookingController::class, 'seatMap']);
        Route::post('/flights/bookings/{booking}/extras', [FlightBookingController::class, 'extras']);
        Route::post('/flights/bookings/{booking}/coupon', [FlightBookingController::class, 'applyCoupon']);
        Route::delete('/flights/bookings/{booking}/coupon', [FlightBookingController::class, 'removeCoupon']);
        Route::post('/flights/bookings/{booking}/confirm', [FlightBookingController::class, 'confirm']);
        Route::post('/flights/bookings/{booking}/pay', [FlightBookingController::class, 'payGateway']);

        Route::apiResource('cashback-rules', CashbackRuleController::class)->only(['index', 'store', 'update', 'destroy']);
        Route::apiResource('payment-method-routes', PaymentMethodRouteController::class)->only(['index', 'store', 'update', 'destroy']);
    });
});
